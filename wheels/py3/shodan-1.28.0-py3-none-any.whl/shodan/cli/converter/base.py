
class Converter:

    def __init__(self, fout):
        self.fout = fout

    def process(self, fout):
        pass
